/*******************************************************************************
* PSoC 101 Training Lessons: ToggleFlipFlop-Test
********************************************************************************
*
* SW2 toggles between off, red, green, yellow, blue, magenta, cyan, and white.
*
*/

#include <project.h>


/*******************************************************************************
* Function Name: main
********************************************************************************
*
* No application code required.
*
* Parameters:	None
*
* Return:		int (not used)
*
*******************************************************************************/
int main()
{
    for(;;)
    {
		/* No application code needed */
    }
}
