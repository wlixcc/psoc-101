/*******************************************************************************
* PSoC 101 Training Lessons: BasicCounter-Test
********************************************************************************
*
* SW2 toggles the output of a 3-bit basic counter on a button press.
*
*/

#include <project.h>


/*******************************************************************************
* Function Name: main
********************************************************************************
*
* No application code required.
*
* Parameters:	None
*
* Return:		int (not used)
*
*******************************************************************************/
int main()
{
    for(;;)
    {
		/* No application code needed */
    }
}