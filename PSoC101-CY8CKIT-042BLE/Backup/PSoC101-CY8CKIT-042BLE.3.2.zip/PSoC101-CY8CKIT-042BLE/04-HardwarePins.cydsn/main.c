/*******************************************************************************
* PSoC 101 Training Lessons: HardwarePins
********************************************************************************
*
* SW2 is tied to the red and green LED pins in PSoC hardware.
*
*/

#include <project.h>


/*******************************************************************************
* Function Name: main
********************************************************************************
*
* No application code required.
*
* Parameters:	None
*
* Return:		int (not used)
*
*******************************************************************************/
int main()
{   
    for(;;)
    {
		/* No application code needed */
    }
}
